/*
 * File: STM32F103_NUCLEO_64_Blinking_LED.c
 *
 * Code generated for Simulink model 'STM32F103_NUCLEO_64_Blinking_LED'.
 *
 * Model version                  : 1.1
 * Simulink Coder version         : 9.0 (R2018b) 24-May-2018
 * C/C++ source code generated on : Fri Jan 25 03:52:43 2019
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: ARM Compatible->ARM Cortex
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "STM32F103_NUCLEO_64_Blinking_LED.h"
#include "STM32F103_NUCLEO_64_Blinking_LED_private.h"

/* Block states (default storage) */
DW_STM32F103_NUCLEO_64_Blinki_T STM32F103_NUCLEO_64_Blinking_DW;

/* Real-time model */
RT_MODEL_STM32F103_NUCLEO_64__T STM32F103_NUCLEO_64_Blinking_M_;
RT_MODEL_STM32F103_NUCLEO_64__T *const STM32F103_NUCLEO_64_Blinking_M =
  &STM32F103_NUCLEO_64_Blinking_M_;

/* Forward declaration for local functions */
static void STM32F103_NU_SystemCore_release(const
  mbed_DigitalWrite_STM32F103_N_T *obj);
static void STM32F103_NUC_SystemCore_delete(const
  mbed_DigitalWrite_STM32F103_N_T *obj);
static void matlabCodegenHandle_matlabCodeg(mbed_DigitalWrite_STM32F103_N_T *obj);
static void STM32F103_NU_SystemCore_release(const
  mbed_DigitalWrite_STM32F103_N_T *obj)
{
  if ((obj->isInitialized == 1) && obj->isSetupComplete) {
    MW_digitalIO_close(obj->MW_DIGITALIO_HANDLE);
  }
}

static void STM32F103_NUC_SystemCore_delete(const
  mbed_DigitalWrite_STM32F103_N_T *obj)
{
  STM32F103_NU_SystemCore_release(obj);
}

static void matlabCodegenHandle_matlabCodeg(mbed_DigitalWrite_STM32F103_N_T *obj)
{
  if (!obj->matlabCodegenIsDeleted) {
    obj->matlabCodegenIsDeleted = true;
    STM32F103_NUC_SystemCore_delete(obj);
  }
}

/* Model step function */
void STM32F103_NUCLEO_64_Blinking_LED_step(void)
{
  real_T rtb_PulseGenerator;

  /* DiscretePulseGenerator: '<Root>/Pulse Generator ' */
  rtb_PulseGenerator = (STM32F103_NUCLEO_64_Blinking_DW.clockTickCounter <
                        STM32F103_NUCLEO_64_Blinking__P.PulseGenerator_Duty) &&
    (STM32F103_NUCLEO_64_Blinking_DW.clockTickCounter >= 0) ?
    STM32F103_NUCLEO_64_Blinking__P.PulseGenerator_Amp : 0.0;
  if (STM32F103_NUCLEO_64_Blinking_DW.clockTickCounter >=
      STM32F103_NUCLEO_64_Blinking__P.PulseGenerator_Period - 1.0) {
    STM32F103_NUCLEO_64_Blinking_DW.clockTickCounter = 0;
  } else {
    STM32F103_NUCLEO_64_Blinking_DW.clockTickCounter++;
  }

  /* End of DiscretePulseGenerator: '<Root>/Pulse Generator ' */

  /* MATLABSystem: '<Root>/Digital Write ' */
  MW_digitalIO_write(STM32F103_NUCLEO_64_Blinking_DW.obj.MW_DIGITALIO_HANDLE,
                     rtb_PulseGenerator != 0.0);
}

/* Model initialize function */
void STM32F103_NUCLEO_64_Blinking_LED_initialize(void)
{
  /* Registration code */

  /* initialize error status */
  rtmSetErrorStatus(STM32F103_NUCLEO_64_Blinking_M, (NULL));

  /* states (dwork) */
  (void) memset((void *)&STM32F103_NUCLEO_64_Blinking_DW, 0,
                sizeof(DW_STM32F103_NUCLEO_64_Blinki_T));

  {
    mbed_DigitalWrite_STM32F103_N_T *obj;
    uint32_T pinname;

    /* Start for DiscretePulseGenerator: '<Root>/Pulse Generator ' */
    STM32F103_NUCLEO_64_Blinking_DW.clockTickCounter = 0;

    /* Start for MATLABSystem: '<Root>/Digital Write ' */
    STM32F103_NUCLEO_64_Blinking_DW.obj.matlabCodegenIsDeleted = true;
    STM32F103_NUCLEO_64_Blinking_DW.obj.isInitialized = 0;
    STM32F103_NUCLEO_64_Blinking_DW.obj.matlabCodegenIsDeleted = false;
    obj = &STM32F103_NUCLEO_64_Blinking_DW.obj;
    STM32F103_NUCLEO_64_Blinking_DW.obj.isSetupComplete = false;
    STM32F103_NUCLEO_64_Blinking_DW.obj.isInitialized = 1;
    pinname = 13;
    obj->MW_DIGITALIO_HANDLE = MW_digitalIO_open(pinname, 1);
    STM32F103_NUCLEO_64_Blinking_DW.obj.isSetupComplete = true;
  }
}

/* Model terminate function */
void STM32F103_NUCLEO_64_Blinking_LED_terminate(void)
{
  /* Terminate for MATLABSystem: '<Root>/Digital Write ' */
  matlabCodegenHandle_matlabCodeg(&STM32F103_NUCLEO_64_Blinking_DW.obj);
}

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
