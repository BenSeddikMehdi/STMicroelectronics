/*
 * File: STM32F103_NUCLEO_64_Blinking_LED_data.c
 *
 * Code generated for Simulink model 'STM32F103_NUCLEO_64_Blinking_LED'.
 *
 * Model version                  : 1.1
 * Simulink Coder version         : 9.0 (R2018b) 24-May-2018
 * C/C++ source code generated on : Fri Jan 25 03:52:43 2019
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: ARM Compatible->ARM Cortex
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "STM32F103_NUCLEO_64_Blinking_LED.h"
#include "STM32F103_NUCLEO_64_Blinking_LED_private.h"

/* Block parameters (default storage) */
P_STM32F103_NUCLEO_64_Blinkin_T STM32F103_NUCLEO_64_Blinking__P = {
  /* Expression: 1
   * Referenced by: '<Root>/Pulse Generator '
   */
  1.0,

  /* Computed Parameter: PulseGenerator_Period
   * Referenced by: '<Root>/Pulse Generator '
   */
  2.0,

  /* Computed Parameter: PulseGenerator_Duty
   * Referenced by: '<Root>/Pulse Generator '
   */
  1.0,

  /* Expression: 0
   * Referenced by: '<Root>/Pulse Generator '
   */
  0.0
};

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
