/*
 * File: STM32F103_NUCLEO_64_Blinking_LED_private.h
 *
 * Code generated for Simulink model 'STM32F103_NUCLEO_64_Blinking_LED'.
 *
 * Model version                  : 1.1
 * Simulink Coder version         : 9.0 (R2018b) 24-May-2018
 * C/C++ source code generated on : Fri Jan 25 03:52:43 2019
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: ARM Compatible->ARM Cortex
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_STM32F103_NUCLEO_64_Blinking_LED_private_h_
#define RTW_HEADER_STM32F103_NUCLEO_64_Blinking_LED_private_h_
#include "rtwtypes.h"
#endif                                 /* RTW_HEADER_STM32F103_NUCLEO_64_Blinking_LED_private_h_ */

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
