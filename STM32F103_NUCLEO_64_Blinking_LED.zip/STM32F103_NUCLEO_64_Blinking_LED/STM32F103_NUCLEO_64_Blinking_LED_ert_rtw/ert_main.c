/*
 * File: ert_main.c
 *
 * Code generated for Simulink model 'STM32F103_NUCLEO_64_Blinking_LED'.
 *
 * Model version                  : 1.1
 * Simulink Coder version         : 9.0 (R2018b) 24-May-2018
 * C/C++ source code generated on : Fri Jan 25 03:52:43 2019
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: ARM Compatible->ARM Cortex
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "STM32F103_NUCLEO_64_Blinking_LED.h"
#include "rtwtypes.h"

volatile int IsrOverrun = 0;
static boolean_T OverrunFlag = 0;
void rt_OneStep(void)
{
  /* Check for overrun. Protect OverrunFlag against preemption */
  if (OverrunFlag++) {
    IsrOverrun = 1;
    OverrunFlag--;
    return;
  }

  __enable_irq();
  STM32F103_NUCLEO_64_Blinking_LED_step();

  /* Get model outputs here */
  __disable_irq();
  OverrunFlag--;
}

volatile boolean_T stopRequested = false;
int main(void)
{
  volatile boolean_T runModel = true;
  float modelBaseRate = 0.5;
  float systemClock = 72;
  (void)systemClock;

#if defined(MW_MULTI_TASKING_MODE) && (MW_MULTI_TASKING_MODE == 1)

  MW_ASM (" SVC #1");

#endif

  ;
  HAL_Init();
  SystemCoreClockUpdate();
  rtmSetErrorStatus(STM32F103_NUCLEO_64_Blinking_M, 0);
  STM32F103_NUCLEO_64_Blinking_LED_initialize();
  ARMCM_SysTick_Config(modelBaseRate);
  runModel =
    rtmGetErrorStatus(STM32F103_NUCLEO_64_Blinking_M) == (NULL);
  __enable_irq();
  ;
  while (runModel) {
    stopRequested = !(
                      rtmGetErrorStatus(STM32F103_NUCLEO_64_Blinking_M) == (NULL));
    runModel = !(stopRequested);
  }

  /* Disable rt_OneStep() here */

  /* Terminate model */
  STM32F103_NUCLEO_64_Blinking_LED_terminate();
  ;
  return 0;
}

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
