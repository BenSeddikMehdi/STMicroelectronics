function RTW_rtwnameSIDMap() {
	this.rtwnameHashMap = new Array();
	this.sidHashMap = new Array();
	this.rtwnameHashMap["<Root>"] = {sid: "STM32F103_NUCLEO_64_Blinking_LED"};
	this.sidHashMap["STM32F103_NUCLEO_64_Blinking_LED"] = {rtwname: "<Root>"};
	this.rtwnameHashMap["<Root>/Dashboard Scope"] = {sid: "STM32F103_NUCLEO_64_Blinking_LED:4"};
	this.sidHashMap["STM32F103_NUCLEO_64_Blinking_LED:4"] = {rtwname: "<Root>/Dashboard Scope"};
	this.rtwnameHashMap["<Root>/Digital Write "] = {sid: "STM32F103_NUCLEO_64_Blinking_LED:3"};
	this.sidHashMap["STM32F103_NUCLEO_64_Blinking_LED:3"] = {rtwname: "<Root>/Digital Write "};
	this.rtwnameHashMap["<Root>/Pulse Generator "] = {sid: "STM32F103_NUCLEO_64_Blinking_LED:1"};
	this.sidHashMap["STM32F103_NUCLEO_64_Blinking_LED:1"] = {rtwname: "<Root>/Pulse Generator "};
	this.getSID = function(rtwname) { return this.rtwnameHashMap[rtwname];}
	this.getRtwname = function(sid) { return this.sidHashMap[sid];}
}
RTW_rtwnameSIDMap.instance = new RTW_rtwnameSIDMap();
