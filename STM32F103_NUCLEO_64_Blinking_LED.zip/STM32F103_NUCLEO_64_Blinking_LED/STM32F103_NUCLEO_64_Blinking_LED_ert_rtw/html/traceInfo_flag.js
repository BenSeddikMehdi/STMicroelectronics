function TraceInfoFlag() {
    this.traceFlag = new Array();
    this.traceFlag["STM32F103_NUCLEO_64_Blinking_LED.c:61c74"]=1;
    this.traceFlag["STM32F103_NUCLEO_64_Blinking_LED.c:62c78"]=1;
    this.traceFlag["STM32F103_NUCLEO_64_Blinking_LED.c:63c55"]=1;
    this.traceFlag["STM32F103_NUCLEO_64_Blinking_LED.c:63c61"]=1;
    this.traceFlag["STM32F103_NUCLEO_64_Blinking_LED.c:65c56"]=1;
    this.traceFlag["STM32F103_NUCLEO_64_Blinking_LED.c:66c61"]=1;
    this.traceFlag["STM32F103_NUCLEO_64_Blinking_LED.c:69c53"]=1;
    this.traceFlag["STM32F103_NUCLEO_64_Blinking_LED.c:76c41"]=1;
    this.traceFlag["STM32F103_NUCLEO_64_Blinking_LED.c:115c35"]=1;
}
top.TraceInfoFlag.instance = new TraceInfoFlag();
function TraceInfoLineFlag() {
    this.lineTraceFlag = new Array();
    this.lineTraceFlag["STM32F103_NUCLEO_64_Blinking_LED.c:61"]=1;
    this.lineTraceFlag["STM32F103_NUCLEO_64_Blinking_LED.c:62"]=1;
    this.lineTraceFlag["STM32F103_NUCLEO_64_Blinking_LED.c:63"]=1;
    this.lineTraceFlag["STM32F103_NUCLEO_64_Blinking_LED.c:64"]=1;
    this.lineTraceFlag["STM32F103_NUCLEO_64_Blinking_LED.c:65"]=1;
    this.lineTraceFlag["STM32F103_NUCLEO_64_Blinking_LED.c:66"]=1;
    this.lineTraceFlag["STM32F103_NUCLEO_64_Blinking_LED.c:67"]=1;
    this.lineTraceFlag["STM32F103_NUCLEO_64_Blinking_LED.c:69"]=1;
    this.lineTraceFlag["STM32F103_NUCLEO_64_Blinking_LED.c:75"]=1;
    this.lineTraceFlag["STM32F103_NUCLEO_64_Blinking_LED.c:76"]=1;
    this.lineTraceFlag["STM32F103_NUCLEO_64_Blinking_LED.c:96"]=1;
    this.lineTraceFlag["STM32F103_NUCLEO_64_Blinking_LED.c:99"]=1;
    this.lineTraceFlag["STM32F103_NUCLEO_64_Blinking_LED.c:100"]=1;
    this.lineTraceFlag["STM32F103_NUCLEO_64_Blinking_LED.c:101"]=1;
    this.lineTraceFlag["STM32F103_NUCLEO_64_Blinking_LED.c:102"]=1;
    this.lineTraceFlag["STM32F103_NUCLEO_64_Blinking_LED.c:103"]=1;
    this.lineTraceFlag["STM32F103_NUCLEO_64_Blinking_LED.c:104"]=1;
    this.lineTraceFlag["STM32F103_NUCLEO_64_Blinking_LED.c:105"]=1;
    this.lineTraceFlag["STM32F103_NUCLEO_64_Blinking_LED.c:106"]=1;
    this.lineTraceFlag["STM32F103_NUCLEO_64_Blinking_LED.c:107"]=1;
    this.lineTraceFlag["STM32F103_NUCLEO_64_Blinking_LED.c:115"]=1;
}
top.TraceInfoLineFlag.instance = new TraceInfoLineFlag();
