/*
 * File: STM32F103_NUCLEO_64_Blinking_LED_types.h
 *
 * Code generated for Simulink model 'STM32F103_NUCLEO_64_Blinking_LED'.
 *
 * Model version                  : 1.1
 * Simulink Coder version         : 9.0 (R2018b) 24-May-2018
 * C/C++ source code generated on : Fri Jan 25 03:52:43 2019
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: ARM Compatible->ARM Cortex
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_STM32F103_NUCLEO_64_Blinking_LED_types_h_
#define RTW_HEADER_STM32F103_NUCLEO_64_Blinking_LED_types_h_
#include "rtwtypes.h"

/* Custom Type definition for MATLABSystem: '<Root>/Digital Write ' */
#include "MW_SVD.h"
#ifndef typedef_mbed_DigitalWrite_STM32F103_N_T
#define typedef_mbed_DigitalWrite_STM32F103_N_T

typedef struct {
  boolean_T matlabCodegenIsDeleted;
  int32_T isInitialized;
  boolean_T isSetupComplete;
  MW_Handle_Type MW_DIGITALIO_HANDLE;
} mbed_DigitalWrite_STM32F103_N_T;

#endif                                 /*typedef_mbed_DigitalWrite_STM32F103_N_T*/

/* Parameters (default storage) */
typedef struct P_STM32F103_NUCLEO_64_Blinkin_T_ P_STM32F103_NUCLEO_64_Blinkin_T;

/* Forward declaration for rtModel */
typedef struct tag_RTM_STM32F103_NUCLEO_64_B_T RT_MODEL_STM32F103_NUCLEO_64__T;

#endif                                 /* RTW_HEADER_STM32F103_NUCLEO_64_Blinking_LED_types_h_ */

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
